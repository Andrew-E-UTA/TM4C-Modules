/*
 * Author:
 *  - Andrew Espinoza
 *
 * Dependencies:
 *  - Jason Losh's tm4c123gh6pm related config and module libraries
 *
 * Target:
 *  - Tiva C TM4C123GH6PM Launchpad Evaluation Board
 *
 */


//C-std libraries
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
//TM4 - config libraries
#include "tm4c123gh6pm.h"
#include "clock.h"
#include "wait.h"
#include "uart0.h"
//TM4 - module libraries
#include "gpio.h"
#include "nvic.h"
#include "shell.h"
#include "i2c0.h"
//Device - libraries
#include "mpu6050.h"


void initHw(void)
{
    initSystemClockTo40Mhz();
}
void pollValidAddresses(void)
{
    uint8_t addr;
    char buffer[20];

    for(addr = 0x8; addr <= 0x77; addr++)
    {
        if(pollI2c0Address(addr))
        {
            htoa(addr, buffer);
            putsUart0("Addr: ");
            putsUart0(buffer);
            putsUart0(" is valid\n");
        }
    }
}

void printData(MpuData *data)
{
    char buffer[80];

    putsUart0(SAVE_POS);
    putsUart0(GOTO_HOME);
    //Print to Uart the readings
    putsUart0("Accelerometer Readings:\n");
    snprintf(buffer, 50, "AX = %10.2lf", data->accel.x);
    putsUart0(buffer);
    putsUart0("\n");
    snprintf(buffer, 50, "AY = %10.2lf", data->accel.y);
    putsUart0(buffer);
    putsUart0("\n");
    snprintf(buffer, 50, "AZ = %10.2lf", data->accel.z);
    putsUart0(buffer);
    putsUart0("\n");


    putsUart0("Gyroscope Readings:\n");
    snprintf(buffer, 50, "GX = %10.2lf", data->gyro.x);
    putsUart0(buffer);
    putsUart0("\n");
    snprintf(buffer, 50, "GY = %10.2lf", data->gyro.y);
    putsUart0(buffer);
    putsUart0("\n");
    snprintf(buffer, 50, "GZ = %10.2lf", data->gyro.z);
    putsUart0(buffer);
    putsUart0("\n");

    putsUart0("Temperature Reading:\n");
    snprintf(buffer, 50, "Temp (C) = %10.2lf", data->temp.c);
    putsUart0(buffer);
    putsUart0("\n");

    putsUart0(RETURN_2_POS);

}

void printPos3d(Pos3d *position)
{
    char buffer[80];

    putsUart0(SAVE_POS);
    putsUart0(GOTO_HOME);
    //Print to Uart the readings
    putsUart0("Position Readings:\n");
    snprintf(buffer, 50, "Pitch = %10.2lf", position->pitch);
    putsUart0(buffer);
    putsUart0("\n");
    snprintf(buffer, 50, "Roll = %10.2lf", position->roll);
    putsUart0(buffer);
    putsUart0("\n");
    snprintf(buffer, 50, "Yaw = %10.2lf", position->yaw);
    putsUart0(buffer);
    putsUart0("\n");

    putsUart0(RETURN_2_POS);
}

void main(void)
{
    initHw();
    initShell(115200, 40e6);
    initI2c0();

    pollValidAddresses();
    initMpu6050(MPU_DEF_ADDR);

    MpuData data = {};
    MpuData offset = {};
    Pos3d   accelPos = {};


    putsUart0(CLEAR_SCREEN);
    putsUart0(GOTO_HOME);
    putsUart0(HIDE_CURSOR);

    putsUart0("\x1B[25;0H");

    //read the mpu and assume this to be the starting accelerometer position
    //used to zero the pitch roll and yaw
    calculateOffset(&data, &offset);

    while(true)
    {
        getMpuData(&data, &offset);
        getAccelPitchRoll(&data, &accelPos);
        printPos3d(&accelPos);

        waitMicrosecond(200e3);
    }
}

